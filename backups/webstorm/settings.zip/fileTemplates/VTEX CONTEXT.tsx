import {${COMPONENT_NAME}ContextProps, ${COMPONENT_NAME}ProviderProps, valuesTheContext${COMPONENT_NAME}ReturnsByDefault} from './utils'

import React, {createContext, useContext, useReducer} from 'react'
import {${COMPONENT_NAME_CAMEL}InitialState, ${COMPONENT_NAME_CAMEL}Reducer} from "./reducer";


export const ${COMPONENT_NAME}Context = createContext<${COMPONENT_NAME}ContextProps>(
	valuesTheContext${COMPONENT_NAME}ReturnsByDefault
)


/**
 *
 * * Criando o provider *
 *
 */

const ${COMPONENT_NAME}Provider = ({
														children
													}: ${COMPONENT_NAME}ProviderProps) => {
	const [${COMPONENT_NAME_CAMEL}, dispath${COMPONENT_NAME}] = useReducer(${COMPONENT_NAME_CAMEL}Reducer, ${COMPONENT_NAME_CAMEL}InitialState)


	const getTerms = () => ${COMPONENT_NAME_CAMEL}.terms
	console.log('dispath', dispath${COMPONENT_NAME})

	return (
		<${COMPONENT_NAME}Context.Provider value={{
			getTerms
		}}>
			{children}
		</${COMPONENT_NAME}Context.Provider>
	)
}

/**
 *
 * * --- --- --- --- Criando o provider --- --- --- --- *
 *
 */

/**
 *
 * * criando o contexto *
 *
 */

const use${COMPONENT_NAME} = () => useContext(${COMPONENT_NAME}Context)

/**
 *
 * * --- --- --- --- criando o contexto --- --- --- --- *
 *
 */

export {
	${COMPONENT_NAME}Provider, use${COMPONENT_NAME}
}
