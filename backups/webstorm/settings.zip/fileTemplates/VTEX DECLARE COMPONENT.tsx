import {${COMPONENT_NAME}} from './components/${COMPONENT_NAME}';


export default ${COMPONENT_NAME};
