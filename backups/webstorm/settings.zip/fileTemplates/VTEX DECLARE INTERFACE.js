  "context-${COMPONENT_NAME_CAMEL}": {
    "component": "${COMPONENT_NAME}Provider"
  },
  "${COMPONENT_NAME_CAMEL}": {
    "component": "${COMPONENT_NAME}",
    "render": "client",
    "around": [
      "context-${COMPONENT_NAME_CAMEL}"
    ]
  },