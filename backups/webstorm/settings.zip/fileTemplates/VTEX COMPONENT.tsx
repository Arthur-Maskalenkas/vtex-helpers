import React from 'react'
import {use${COMPONENT_NAME}} from "./context";

export const ${COMPONENT_NAME} = () => {
	const {getTerms} = use${COMPONENT_NAME}()


	console.log(getTerms)
	return (
		<div>
			${COMPONENT_NAME}ddasdas
		</div>
	)
}
