import { Dispatch, ReactNode, SetStateAction } from 'react'

/*
  * Valores que o contexto vai receber quando invocado no componente
*/
export type ${NAME_CONTEXT}ProviderProps = {
  children: ReactNode
}

/*
  * Estados presentes no Contexto
*/

export type ${NAME_CONTEXT}StateProps = {
  isLoading: boolean

}

export const ${NAME_CONTEXT}StateDefaultValues: ${NAME_CONTEXT}StateProps = {
  isLoading: false
}

/*
  * Conteudo retornado pelo Contexto
*/

export type ${NAME_CONTEXT}ContextProps = {
  state${NAME_CONTEXT}: ${NAME_CONTEXT}StateProps
  setState${NAME_CONTEXT}: Dispatch<SetStateAction<${NAME_CONTEXT}StateProps>>
  verifyIfIsLoading: () => boolean
}

export const valuesTheContext${NAME_CONTEXT}ReturnsByDefault: ${NAME_CONTEXT}ContextProps = {
  state${NAME_CONTEXT}: ${NAME_CONTEXT}StateDefaultValues,
  setState${NAME_CONTEXT}: () => null,
  verifyIfIsLoading: () => false
}
