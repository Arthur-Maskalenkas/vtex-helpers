import React from 'react'
import { render, screen, RenderResult } from '@testing-library/react'
import { ${COMPONENT_NAME}, ${COMPONENT_NAME}Props } from '.'

type SutTypes = {
  sut: RenderResult
}

const makeSut = (props?: Partial<${COMPONENT_NAME}Props>): SutTypes => {
  const sut = render(<${COMPONENT_NAME} {...props} />)

  return {
    sut
  }
}

describe('${COMPONENT_NAME}', () => {
  test('Should render ${COMPONENT_NAME} correctly', () => {
    makeSut()
    
    expect(screen.getByText(/${COMPONENT_NAME}/i)).toBeInTheDocument()
  })
})
