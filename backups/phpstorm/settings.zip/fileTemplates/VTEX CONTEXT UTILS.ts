import {ReactNode} from 'react'

export type ${COMPONENT_NAME}ProviderProps = {
	children: ReactNode
}

export type ${COMPONENT_NAME}ContextProps = {
	getTerms: () => string[]
}

export const valuesTheContext${COMPONENT_NAME}ReturnsByDefault: ${COMPONENT_NAME}ContextProps = {
	getTerms: () => []
}
