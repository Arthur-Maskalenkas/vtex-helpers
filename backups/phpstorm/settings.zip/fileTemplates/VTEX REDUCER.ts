export type ${COMPONENT_NAME}ReducerProps = {
	terms: string[] | []
}

export const ${COMPONENT_NAME_CAMEL}InitialState: ${COMPONENT_NAME}ReducerProps = {
	terms: [],
}

export type ${COMPONENT_NAME}Actions =
	{
		type: "SET_${COMPONENT_NAME}_TERMS"
		payload: string[] | []
	}


export const ${COMPONENT_NAME_CAMEL}Reducer = (state: ${COMPONENT_NAME}ReducerProps, action: ${COMPONENT_NAME}Actions): ${COMPONENT_NAME}ReducerProps => {
	switch (action.type) {
		case "SET_${COMPONENT_NAME}_TERMS":
			return {
				...state,
				terms: action.payload,
			}
		default:
			return state
	}
}
