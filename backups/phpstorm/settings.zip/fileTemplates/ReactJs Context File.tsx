import {
  ${NAME_CONTEXT}ContextProps,
  ${NAME_CONTEXT}ProviderProps,
  ${NAME_CONTEXT}StateDefaultValues,
  ${NAME_CONTEXT}StateProps,
  valuesTheContext${NAME_CONTEXT}ReturnsByDefault
} from './utils'

import React, { createContext, useContext } from 'react'

/**
 *
 * * Criando o contexto *
 *
 */

export const ${NAME_CONTEXT}Context = createContext<${NAME_CONTEXT}ContextProps>(
  valuesTheContext${NAME_CONTEXT}ReturnsByDefault
)

/**
 *
 * * --- --- --- --- Criando o contexto --- --- --- --- *
 *
 */

/**
 *
 * * Criando o provider *
 *
 */

const ${NAME_CONTEXT}Provider = ({
  children
}: ${NAME_CONTEXT}ProviderProps) => {
  const [state${NAME_CONTEXT}, setState${NAME_CONTEXT}] = React.useState<${NAME_CONTEXT}StateProps>(${NAME_CONTEXT}StateDefaultValues)
  
  const verifyIfIsLoading = () => state${NAME_CONTEXT}.isLoading
  
  return (
    <${NAME_CONTEXT}Context.Provider value={{
      state${NAME_CONTEXT},
      setState${NAME_CONTEXT},
      verifyIfIsLoading
    }}>
      {children}
    </${NAME_CONTEXT}Context.Provider>
  )
}

/**
 *
 * * --- --- --- --- Criando o provider --- --- --- --- *
 *
 */

/**
 *
 * * criando o contexto *
 *
 */

const use${NAME_CONTEXT} = () => useContext(${NAME_CONTEXT}Context)

/**
 *
 * * --- --- --- --- criando o contexto --- --- --- --- *
 *
 */

export {
  ${NAME_CONTEXT}Provider, use${NAME_CONTEXT}
}
