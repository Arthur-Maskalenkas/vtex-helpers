import { act, renderHook } from '@testing-library/react'
import { ${NAME_CONTEXT}Provider, use${NAME_CONTEXT} } from '.'
import { ${NAME_CONTEXT}StateDefaultValues } from './utils'

const makeSut = () => {
  const { result } = renderHook(() => use${NAME_CONTEXT}(), {
    wrapper: ${NAME_CONTEXT}Provider
  })

  return result
}

describe('${NAME_CONTEXT}Context', () => {
  describe('verifyIfIsLoading()', () => {
    it('🟥 should return true if isLoading is true', () => {
      const sut = makeSut()

      act(() => {
        sut.current.setState${NAME_CONTEXT}({
          ...${NAME_CONTEXT}StateDefaultValues,
          isLoading: true
        })
      })

      expect(sut.current.verifyIfIsLoading()).toBe(true)
    })

    it('🟩 should return false if isLoading is false', () => {
      const sut = makeSut()

      expect(sut.current.verifyIfIsLoading()).toBe(false)
    })
  })
})
