import React from 'react'
import {${COMPONENT_NAME}ProviderProps} from "./components/${COMPONENT_NAME}/context/utils";
import {${COMPONENT_NAME}Provider as ${COMPONENT_NAME}Prov} from "./components/${COMPONENT_NAME}/context";

const ${COMPONENT_NAME}Provider = ({children}: ${COMPONENT_NAME}ProviderProps) => (
	<${COMPONENT_NAME}Prov>
		{children}
	</${COMPONENT_NAME}Prov>
)

export default ${COMPONENT_NAME}Provider
