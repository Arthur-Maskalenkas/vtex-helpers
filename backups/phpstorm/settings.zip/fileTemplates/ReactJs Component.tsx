import React from 'react'
import styles from './styles.scss'

export const ${COMPONENT_NAME} = () => {
  return (
    <div className={styles.wrapper${COMPONENT_NAME}}>
      ${COMPONENT_NAME}
    </div>
  )
}
